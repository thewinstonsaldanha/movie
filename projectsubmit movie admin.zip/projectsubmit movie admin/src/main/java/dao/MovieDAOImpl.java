package dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Movie;
import com.model.Status;







public class MovieDAOImpl {
    private Connection connection;

    // Default constructor
    public MovieDAOImpl() {
        // Establish database connection
        connection = DBUtil.getConnection();
    }

    // Method to add a new movie
    public Status addMovie(Movie movie) {
        Status status = new Status();
        try {
            String query = "INSERT INTO movies (movie_id, movie_name, movie_language, movie_genre, movie_image) VALUES (?, ?, ?, ?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, movie.getMovieId());
            preparedStatement.setString(2, movie.getMovieName());
            preparedStatement.setString(3, movie.getMovieLanguage());
            preparedStatement.setString(4, movie.getMovieGenre());
            preparedStatement.setString(5, movie.getMovieImage());

            int rowsAffected = preparedStatement.executeUpdate();
            try {
            if (rowsAffected > 0) {
                status.setQueryStatus(true);
                status.setMessage("Movie added successfully");
            } else {
                status.setQueryStatus(false);
                status.setMessage("Failed to add movie");
            }
            }
            catch(Exception e)
            {
            	e.printStackTrace();
                status.setQueryStatus(false);
                status.setMessage("Error occurred while adding movie");
            }
        } catch (SQLException e) {
        	System.out.println("This is Error");
            e.printStackTrace();
            status.setQueryStatus(false);
            
            status.setMessage("Error occurred while adding movie");
        }
        return status;
    }

    // Method to update an existing movie
    public Status updateMovie(Movie movie) {
        Status status = new Status();
        System.out.println(movie);
        try {
            String query = "UPDATE movies SET movie_name=?, movie_language=?, movie_genre=?, movie_image=? WHERE movie_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, movie.getMovieName());
            preparedStatement.setString(2, movie.getMovieLanguage());
            preparedStatement.setString(3, movie.getMovieGenre());
            preparedStatement.setString(4, movie.getMovieImage());
            preparedStatement.setInt(5, movie.getMovieId());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                status.setQueryStatus(true);
                status.setMessage("Movie updated successfully");
            } else {
                status.setQueryStatus(false);
                status.setMessage("Failed to update movie");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            status.setQueryStatus(false);
            status.setMessage("Error occurred while updating movie");
        }
        return status;
    }

    // Method to delete a movie by ID
    public Status deleteMovie(int movieId) {
        Status status = new Status();
        try {
            String query = "DELETE FROM movies WHERE movie_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, movieId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                status.setQueryStatus(true);
                status.setMessage("Movie deleted successfully");
            } else {
                status.setQueryStatus(false);
                status.setMessage("Failed to delete movie");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            status.setQueryStatus(false);
            status.setMessage("Error occurred while deleting movie");
        }
        return status;
    }

    // Method to retrieve a movie by ID
    public Movie getMovieByName(String movieName) {
        Movie movie = null;
        try {
            String query = "SELECT * FROM movies WHERE lower(movie_name)=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, movieName.toLowerCase());
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                movie = new Movie();
                System.out.println(resultSet.getInt("movie_id"));
                System.out.println(resultSet.getString("movie_name"));
                movie.setMovieId(resultSet.getInt("movie_id"));
                movie.setMovieName(resultSet.getString("movie_name"));
                movie.setMovieLanguage(resultSet.getString("movie_language"));
                movie.setMovieGenre(resultSet.getString("movie_genre"));
                movie.setMovieImage(resultSet.getString("movie_image"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
        return movie;
    }

    public Movie getMovieById(int id) {
        Movie movie = null;
        try {
            String query = "SELECT * FROM movies WHERE movie_id=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                movie = new Movie();
                System.out.println(resultSet.getInt("movie_id"));
                System.out.println(resultSet.getString("movie_name"));
                movie.setMovieId(resultSet.getInt("movie_id"));
                movie.setMovieName(resultSet.getString("movie_name"));
                movie.setMovieLanguage(resultSet.getString("movie_language"));
                movie.setMovieGenre(resultSet.getString("movie_genre"));
                movie.setMovieImage(resultSet.getString("movie_image"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
        return movie;
    }
    // Method to retrieve all movies
    public List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        try {
            String query = "SELECT * FROM movies";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Movie movie = new Movie();
                movie.setMovieId(resultSet.getInt("movie_id"));
                movie.setMovieName(resultSet.getString("movie_name"));
                movie.setMovieLanguage(resultSet.getString("movie_language"));
                movie.setMovieGenre(resultSet.getString("movie_genre"));
                movie.setMovieImage(resultSet.getString("movie_image"));
               
                movies.add(movie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
        return movies;
    }
}



