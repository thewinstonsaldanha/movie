package dao;

import com.model.Status;

public class User {

    private int userId;
    private String userName;
    private String userEmail;
    private String userPassword;
    private String userBio;
    private String userAvatar;
    private boolean isAdmin;
    
    public User() {
		// TODO Auto-generated constructor stub
	}
    
	public User(int userId, String userName, String userEmail, String userPassword, String userBio, String userAvatar,boolean isAdmin) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPassword = userPassword;
		this.userBio = userBio;
		this.userAvatar = userAvatar;
		this.isAdmin= isAdmin;
	}

	

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserBio() {
		return userBio;
	}

	public void setUserBio(String userBio) {
		this.userBio = userBio;
	}

	public String getUserAvatar() {
		return userAvatar;
	}

	public void setUserAvatar(String userAvatar) {
		this.userAvatar = userAvatar;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userEmail=" + userEmail + ",userBio=" + userBio + ", userAvatar=" + userAvatar + "]";
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	
	

    

    
}
