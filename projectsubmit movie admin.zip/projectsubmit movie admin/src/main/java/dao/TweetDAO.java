package dao;

import java.sql.SQLException;
import java.util.List;

public interface TweetDAO {

    int addTweet(Tweet tweet) throws SQLException;

    List<Tweet> viewMyTweets(int u_id) throws SQLException;

    int updateTweet(Tweet tweet) throws SQLException;

    int deleteTweet(int t_id) throws SQLException;

	List<Tweet> viewAllTweets() throws SQLException;

}