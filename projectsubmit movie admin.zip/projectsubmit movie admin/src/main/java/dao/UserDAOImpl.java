package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.Status;

public class UserDAOImpl implements UserDAO {

    private Connection connection;

    public UserDAOImpl() {
        this.connection = DBUtil.getConnection();
    }

    @Override
    public Status signUp(User user) throws SQLException {
    	Status s = new Status();
		int res = -1;
    	String query = "INSERT INTO \"USER\" (u_id,u_name, u_email, u_password, u_bio, u_avatar,u_isAdmin) VALUES (?, ?, ?, ?, ?, ?,?)";


        try (PreparedStatement pst = connection.prepareStatement(query)) {
        	pst.setInt(1, user.getUserId());
            pst.setString(2, user.getUserName());
            pst.setString(3, user.getUserEmail());
            pst.setString(4, user.getUserPassword());
            pst.setString(5, user.getUserBio());
            pst.setString(6, user.getUserAvatar());
            pst.setBoolean(7, false);

            res = pst.executeUpdate();
            System.out.println("User registration successful!");
            s.setQueryStatus((res == 1) ? true : false);
            return s;
            
        }
    }

    @Override
    public int signIn(String userEmail, String userPassword) throws SQLException {
    	String query = "SELECT * FROM `user` WHERE u_email = ? AND u_password = ?";

        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, userEmail);
            pst.setString(2, userPassword);

            try (ResultSet rs = pst.executeQuery()) {
            	if (rs.next()) {
                    return rs.getInt("u_id");
                } else {
                    return -1; 
                }
            }
        }
    }

    @Override
    public User viewProfile(int userId) throws SQLException {
        String query = "SELECT * FROM `user` WHERE u_id = ?";
        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setInt(1, userId);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    User user = new User(rs.getInt("u_id"),rs.getString("u_name"),rs.getString("u_email"),rs.getString("u_password"),rs.getString("u_bio"),rs.getString("u_avatar"),rs.getBoolean("u_isAdmin"));
        
                    return user;
                }
                return null;
            }
        }
    }

    @Override
    public int updateProfile(User user) throws SQLException {
        String query = "UPDATE `user` SET u_name=?, u_email=?, u_password=?, u_bio=?, u_avatar=? WHERE u_id=?";
        try (PreparedStatement pst = connection.prepareStatement(query)) {
            pst.setString(1, user.getUserName());
            pst.setString(2, user.getUserEmail());
            pst.setString(3, user.getUserPassword());
            pst.setString(4, user.getUserBio());
            pst.setString(5, user.getUserAvatar());
            pst.setInt(6, user.getUserId());

            int res = pst.executeUpdate();
           
            return res;
        }
    }

   
}
