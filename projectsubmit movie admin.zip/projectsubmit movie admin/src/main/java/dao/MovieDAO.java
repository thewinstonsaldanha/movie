package dao;

import java.util.List;

import com.model.Movie;

public interface MovieDAO {
    boolean addMovie(Movie movie);
    boolean deleteMovie(int movieId);
    boolean updateMovie(Movie movie);
    List<Movie> getAllMovies();
}
