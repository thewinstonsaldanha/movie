package com.model;

public class Movie {
    private int movieId;
    private String movieName;
    private String movieLanguage;
    private String movieGenre;
   private String movieImage;

    // Constructors
    public Movie() {
    }

    public Movie(int movieId, String movieName, String movieLanguage, String movieGenre, String movieImage) {
        this.movieId = movieId;
        this.movieName = movieName;
        this.movieLanguage = movieLanguage;
        this.movieGenre = movieGenre;
        this.movieImage=movieImage;
//        this.castId = castId;
    }

    // Getters and Setters
    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieLanguage() {
        return movieLanguage;
    }

    public void setMovieLanguage(String movieLanguage) {
        this.movieLanguage = movieLanguage;
    }

    public String getMovieGenre() {
        return movieGenre;
    }

    public void setMovieGenre(String movieGenre) {
        this.movieGenre = movieGenre;
    }

//    public int getCastId() {
//        return castId;
//    }
//
//    public void setCastId(int castId) {
//        this.castId = castId;
//    }
    

    // toString method
    
	public String getMovieImage() {
		return movieImage;
	}

	public void setMovieImage(String movieImage) {
		this.movieImage = movieImage;
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", movieLanguage=" + movieLanguage
				+ ", movieGenre=" + movieGenre + ", movieImage=" + movieImage + "]";
	}
	
}
