package com.postbook;

import java.sql.SQLException;


import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.model.Movie;
import com.model.Status;

import dao.MovieDAOImpl;
import dao.User;
import dao.UserDAOImpl;

@Path("moviereview")
public class MyResource {
    
    MovieDAOImpl movieDAOImpl = new MovieDAOImpl();
    UserDAOImpl userImpl= new UserDAOImpl();
    @Path("movie/add")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Status addMovie(Movie movie) {
        return movieDAOImpl.addMovie(movie);
    }
    
    @Path("movie/edit")
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Status editMovie(Movie movie) {
        return movieDAOImpl.updateMovie(movie);
    }
    
    @Path("movie/delete/{id}")
    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    public Status deleteMovie(@PathParam("id") int id) {
        return movieDAOImpl.deleteMovie(id);
    }
    
    @Path("movie/{Name}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Movie getMovieById(@PathParam("Name") String movieName) {
        return movieDAOImpl.getMovieByName(movieName);
    }
    
    @Path("movie/find/{id}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Movie getMovieById(@PathParam("id") int id) {
        return movieDAOImpl.getMovieById(id);
    }
    @Path("movies")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Movie> getAllMovies() {
        return movieDAOImpl.getAllMovies();
        
    }
    
    @Path("signin")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public int loginUser(String userEmail, String userPassword) throws SQLException{
    	return userImpl.signIn( userEmail, userPassword);
    }
    
    @Path("signup")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Status addUser(User user) throws SQLException{
    	return userImpl.signUp(user);
    }
}












