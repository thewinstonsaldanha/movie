package dao;

import java.sql.SQLException;
import java.util.List;

import com.model.Category;
import com.model.Status;

public interface CategoryDAO {
	Status addCategory(Category category) throws SQLException;   //post
	Status updateCategory(Category category) throws SQLException; //put
	List<Category> getAllCategories() throws SQLException; //get method
	Status deleteCategory(int categoryId) throws SQLException;    //delete

}
